<?php
namespace gateways\upay\controller;

class AdminIndexController extends \think\Controller
{
    // 后台管理控制器，可根据需要添加管理功能
}

?>