# UpayPro 支付插件

## 简介

UpayPro 是一个专为 XBoard 设计的 USDT 支付插件，支持多种区块链网络的 USDT 和 USDC 支付。

## 特性

- 支持多种支付通道：USDT-TRC20、TRX、USDT-Polygon、USDT-BSC、USDT-ERC20、USDT-ArbitrumOne、USDC-ERC20、USDC-Polygon、USDC-BSC、USDC-ArbitrumOne
- 优化的异步回调处理，修复了500错误问题
- 完整的签名验证机制
- 详细的日志记录

## 安装

1. 将插件文件放置在 `plugins/UpayPro/` 目录下
2. 在管理后台的插件管理中安装并启用插件
3. 配置插件参数

## 配置参数

- **API 地址**: 您的 EPUSDT API 接口地址
- **Secret Key**: 系统安全密钥，需与后端保持一致
- **支付通道**: 选择要使用的支付通道类型
- **显示名称**: 前端显示的支付方式名称
- **图标**: 支付方式图标

## 版本历史

### v1.0.0
- 初始版本
- 支持多种 USDT/USDC 支付通道
- 优化回调处理机制
- 完善错误处理和日志记录

## 技术支持

如有问题，请联系 XBoard 社区获取技术支持。