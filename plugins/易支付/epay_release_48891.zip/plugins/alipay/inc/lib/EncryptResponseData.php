<?php
/**
 *  TODO 补充说明
 *
 * User: jiehua
 * Date: 16/3/30
 * Time: 下午8:51
 */

class EncryptResponseData
{
    public $realContent;

    public $returnContent;

} 