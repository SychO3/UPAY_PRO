<?php
define('authcode','bd19807b84f6c7654f529ae5445b8daa');

?>